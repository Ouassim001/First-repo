print("a is python")
print("b is javascript")
print("c is java")
print("d is c")


vraag1 = input("welke programmeertaal gebruiken we op school? ")
if vraag1 =="a":
        print("correct")

else:
        print("incorrect")

print("a is groen en wit")
print("b is geel en blauw")
print("c is blauw en blauw")
print("d is zwart en geel")

vraag2 = input("welke kleuren zitten in de python logo? ")
if vraag2 =="b":
        print("correct")
else:
        print("incorrect")

print("a is niet gelijk aan")
print("b is kleiner dan")
print("c is gelijk aan")
print("d is groter dan")

vraag3 = input("wat betekent ==? ")
if vraag3 =="c":
        print("correct")
else:
        print("incorrect")

print("a is kleiner")
print("b is groter dan")
print("c is evengroot")
print("d is groter")

vraag4 = input("wat betekent <? ")
if vraag4 =="a":
        print("correct")    
else:
        print("incorrect")

print("a is groter")
print("b is kleiner")
print("c is evengroot")
print("d is zwart")


vraag5 = input("wat betekent >? ")
if vraag5 =="a":
        print("correct")

else:
        print("incorrect")
print("5/5 correct")

