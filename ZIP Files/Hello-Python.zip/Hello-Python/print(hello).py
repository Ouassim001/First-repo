print('hello') # output to terminal

input('whats your name: ') 
name = input('okay')
input('whats your studentnumber ')
studentnumber = print('good')
